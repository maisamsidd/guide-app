class UserModel {
  String? email;
  String? name;
  String? lastName;
  String? contactNumber;
  String? userId;

  UserModel(
      {this.email, this.name, this.lastName, this.contactNumber, this.userId});

  UserModel.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    name = json['name'];
    lastName = json['last_name'];
    contactNumber = json['contact_number'];
    userId = json['userId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['email'] = email;
    data['name'] = name;
    data['last_name'] = lastName;
    data['contact_number'] = contactNumber;
    data['userId'] = userId;
    return data;
  }
}
